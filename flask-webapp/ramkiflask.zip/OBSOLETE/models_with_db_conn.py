from sqlalchemy import Table,Column, Integer, String, ForeignKey
from sqlalchemy.types import Date, DateTime, Enum
from werkzeug.security import generate_password_hash, check_password_hash

#import enum

from db_conn import Base, engine

class Usertype(Base):
    __tablename__ = 'usertype'

    id = Column(Integer, primary_key=True)
    name = Column(String)

    def __repr__(self):
        return "<UserType(name='{}'>".format(self.name)

class User(Base):
    __tablename__ = 'user'

    id = Column(Integer, primary_key=True)
    firstname = Column(String, nullable=True)
    lastname = Column(String, nullable=True)
    username = Column(String, nullable=True)
    password_hash = Column(String, nullable=True)

    def set_password(self, password):
      self.password_hash = generate_password_hash(password)

    def check_password(self, password):
      return check_password_hash(self.password_hash, password)

    def __repr__(self):
        return "<User(username='{}', firstname='{}', lastname='{}')>".format(self.username, self.firstname, self.lastname)

class Todo(Base):
    __tablename__ = 'todo'

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('user.id'), nullable=True)
    task = Column(String, nullable=True)
    status = Column(Enum("Open", "In Progress", "On Hold", "Completed", "Rejected", name="status"))
    created = Column(String, nullable=True)
    updated = Column(String, nullable=True)

    def __repr__(self):
        return "<Todo(userid='{}', task='{}', status='{}')>".format(self.user_id, self.task, self.status)


Base.metadata.create_all(engine)
