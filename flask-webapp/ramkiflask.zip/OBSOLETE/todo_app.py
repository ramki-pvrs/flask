#https://hackersandslackers.com/your-first-flask-application/
#https://overiq.com/flask-101/form-handling-in-flask/
#https://itnext.io/start-using-env-for-your-flask-project-and-stop-using-environment-variables-for-development-247dc12468be

import logging
from flask import Flask, flash
from flask_script import Manager

from flask_wtf.csrf import CSRFProtect
import config

#todo_app = Flask(
#        __name__,
#        instance_relative_config=False,
#        template_folder="templates",
#        static_folder="static"
#        )

todo_app = Flask(__name__, instance_relative_config=False)
csrf = CSRFProtect()
csrf.init_app(todo_app)

#todo_app.config.from_pyfile('config.py')
todo_app.config.from_object('config.DevConfig')
#CSRFProtect(todo_app)


#todo_app.secret_key="whytodoanythingatall"

#session data
username = ''

from routes import *
from forms import SignupForm
from werkzeug.datastructures import MultiDict

if __name__ == '__main__':
    #with debug=True, your changes are reflected online
    #you dont have to restart server, no Ctrl-C
    todo_app.run(port=7000, debug=True)

    #from forms import SignupForm; from werkzeug.datastructures import MultiDict;form1 = SignupForm(MultiDict([('firstname', 'ramki'), ('lastname', 'Srinivasan'), ('username','srinivasanr'), ('password', 'ramki_123'), ('confirm', 'ramki_123')]), csrf_enabled=False);form1.validate();form1.errors
    #manager = Manager(todo_app)
    #manager.run()

